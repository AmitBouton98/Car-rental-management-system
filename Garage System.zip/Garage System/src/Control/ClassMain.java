package Control;


import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.Serializable;

import Users.Manager;

/**
 * This is class main
 * @author Amit
 *
 */
public class ClassMain implements Serializable{
	
	/**
	 * Serial number
	 */
	private static final long serialVersionUID = 8922430941838390924L;

	/**
	 * main
	 * @param args
	 */
	public static void main(String[] args) {
		Manager Admin = new Manager();
		/**
		 * check if file exists
		 */
		if((new File("data.ser").exists()))
		{
			Admin = Admin.Load();
		}
		Screens.SignInORegister S = new Screens.SignInORegister(Admin);
		S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
	    S.setLocation(x, y);
		S.setVisible(true);
	}
	
}
