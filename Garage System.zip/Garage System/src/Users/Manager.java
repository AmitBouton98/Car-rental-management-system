package Users;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


import Entities.Branch;
import Entities.Car;

/**
 * this class represent Manager
 * @author Amit
 *
 */
public class Manager implements Serializable{
	// -------------------------------Class Members------------------------------
	/**
	 * Email and Password for Manager
	 */
	private static final String Email ="Admin@Admin.com";	
	private static final String Passoword= "Admin123";
	/**
	 * The customers
	 */
	private ArrayList<Customer> customers;
	/**
	 * The branchs
	 */
	private ArrayList<Branch> branchs;
	/**
	 * The cars
	 */
	private ArrayList<Car> cars;
	/**
	 * key is the branch number, and the values is the cars in this branch
	 */
	private Map<Integer,ArrayList<Car>> carsPerStore;

	// -------------------------------serialVersionUID------------------------------
	/**
	 * This is serial number for Version
	 */
	private static final long serialVersionUID = 4793977202268232421L;
	
	
	// -------------------------------Constructors&Instance------------------------------

	public Manager() {
		super();
		this.customers = new ArrayList<Customer>();
		this.branchs = new ArrayList<Branch>();
		this.cars=new ArrayList<Car>();
		this.carsPerStore=new HashMap<Integer,ArrayList<Car>>();
	}
	// -----------------------------------------Setters&&Getters--------------------------------------
	/**
	 * Getter for Email
	 * @return Email
	 */
	public String getEmail() {
		return Email;
	}

	/**
	 * Setter for Email
	 * @param email
	 */
	//public void setEmail(String email) {
	//	Email = email;
	//}

	/**
	 * Getter for password
	 * @return Passoword
	 */
	public String getPassoword() {
		return Passoword;
	}

	/**
	 * Setter for Passoword
	 * @param passoword
	 */
	//public void setPassoword(String passoword) {
	//	Passoword = passoword;
	//}

	/**
	 * Getter for customers
	 * @return customers
	 */
	public ArrayList<Customer> getCustomers() {
		return customers;
	}

	/**
	 * Setter for customers
	 * @param customers
	 */
	public void setCustomers(ArrayList<Customer> customers) {
		this.customers = customers;
	}

	/**
	 * Getter for branchs
	 * @return branchs
	 */
	public  ArrayList<Branch> getBranchs() {
		return branchs;
	}

	/**
	 * Setter for branchs
	 * @param branchs
	 */
	public void setBranchs(ArrayList<Branch> branchs) {
		this.branchs = branchs;
	}

	/**
	 * Getter for cars
	 * @return cars
	 */
	public ArrayList<Car> getCars() {
		return cars;
	}

	/**
	 * Setter for cars
	 * @param cars
	 */
	public void setCars(ArrayList<Car> cars) {
		this.cars = cars;
	}

	/**
	 * Getter for carsPerStore
	 * @return
	 */
	public Map<Integer, ArrayList<Car>> getCarsPerStore() {
		return carsPerStore;
	}

	/**
	 * Setter for carsPerStore
	 * @param carsPerStore
	 */
	public void setCarsPerStore(Map<Integer, ArrayList<Car>> carsPerStore) {
		this.carsPerStore = carsPerStore;
	}
	/**
	 * this method save Manager Admin in file
	 * @param Admin
	 */
	public void Save(Manager Admin) {
		String filename = "data.ser";
		FileOutputStream fos = null;
		ObjectOutputStream out = null;
		try {
			fos = new FileOutputStream(filename);
			out = new ObjectOutputStream(fos);
			out.writeObject(Admin);
			out.close();
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
	}
	/**
	 * this method load Manager from file
	 * @return Manager who is the Admin
	 */
	public Manager Load() {
		String filename = "data.ser";
		Manager Admin = null;
		FileInputStream fis = null;
		ObjectInputStream in = null;
		try {
            fis = new FileInputStream(filename);
            in = new ObjectInputStream(fis);
            Admin = (Manager)in.readObject();
			in.close();
		}
		catch(IOException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		return Admin;
	}
	// -------------------------------All Methods------------------------------
	/**
	 * Adding new customer to customer array
	 * @param add - customer to add
	 */
	public void AddCustomer(Customer add) {
		this.customers.add(add);
	}
	/**
	 * adding new car to car array
	 * @param add - car to add
	 */
	public void AddCar(Car add) {
		this.cars.add(add);
	}
	/**
	 * add branch to branch array
	 * @param add - branch to add
	 */
	public void AddBranch(Branch add) {
		this.branchs.add(add);
	}
	/**
	 * adding new car to store
	 * @param key - the key in hashmap
	 * @param add - the car to add to array
	 */
	public void AddCarPerStore(Integer key,Car add) {
		this.carsPerStore.get(key).add(add);
	}
	/**
	 * adding new branck key
	 * @param key - key number to add
	 */
	public void AddBranchToCarPerStore(Integer key) {
		this.carsPerStore.put(key, new ArrayList<Car>());
	}
	// -------------------------------hashCode equals & toString------------------------------


	/**
	 * hashCode
	 */
	@Override
	public int hashCode() {
		return Objects.hash(Email, Passoword);
	}

	/**
	 * Check if given Manager is the same as this
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Manager other = (Manager) obj;
		/**
		 * it always be true before the email and password and final
		 */
		return Objects.equals(Email, other.Email) && Objects.equals(Passoword, other.Passoword);
	}

	/**
	 * return string with all the manager data
	 */
	@Override
	public String toString() {
		return "Manager [Email=" + Email + ", Passoword=" + Passoword + "]";
	}

}
