package Users;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import Entities.Car;

/**
 * This class represent Customer
 * @author Amit
 *
 */
public class Customer implements Serializable{
// -------------------------------Class Members------------------------------
/**
 * First name
 */
private String First;
/**
 * Last name
 */
private String Last;
/**
 * ID
 */
private int ID;
/**
 * Email
 */
private String Email;
/**
 * birth date
 */
private String BirthDate;
/**
 * License issuance Year 
 */
private int Year;
/**
 * Password
 */
private String Password;
/**
 * The cars
 */
private Map<String,ArrayList<Car>> cars;


// -------------------------------serialVersionUID------------------------------
/**
 * This is serial number for Version
 */
private static final long serialVersionUID = 3L;

// -------------------------------Constructors------------------------------
/**
 * This is constructor for Customer
 * @param first
 * @param last
 * @param iD
 * @param email
 * @param birthDate
 * @param year
 * @param password
 */
public Customer(String first, String last, int iD, String email, String birthDate, int year, String password) {
	super();
	First = first;
	Last = last;
	ID = iD;
	Email = email;
	BirthDate = birthDate;
	Year = year;
	Password = password;
	cars = new HashMap<String,ArrayList<Car>>();
}
// -----------------------------------------Setters&&Getters--------------------------------------
/**
 * Getter for cars
 * @return cars
 *  */
public Map<String,ArrayList<Car>> getCars() {
	return cars;
}

/**
 * Setter for cars
 * @param cars
 */
public void setCars(Map<String,ArrayList<Car>> cars) {
	this.cars = cars;
}
/**
 * Getter for first
 * @return first
 */
public String getFirst() {
	return First;
}

/**
 * Setter for first
 * @param first
 */
public void setFirst(String first) {
	First = first;
}

/**
 * Getter for Last
 * @return Last
 */
public String getLast() {
	return Last;
}

/**
 * Setter for Last
 * @param last
 */
public void setLast(String last) {
	Last = last;
}

/**
 * Getter for ID
 * @return ID
 */
public int getID() {
	return ID;
}

/**
 * Setter for ID
 * @param iD
 */
public void setID(int iD) {
	ID = iD;
}

/**
 * Getter for email
 * @return email
 */
public String getEmail() {
	return Email;
}

/**
 * Setter for email
 * @param email
 */
public void setEmail(String email) {
	Email = email;
}

/**
 * Getter for birthDate
 * @return birthDate
 */
public String getBirthDate() {
	return BirthDate;
}

/**
 * Setter for birthDate
 * @param birthDate
 */
public void setBirthDate(String birthDate) {
	BirthDate = birthDate;
}

/**
 * Getter for year
 * @return year
 */
public int getYear() {
	return Year;
}

/**
 * Setter for year
 * @param year
 */
public void setYear(int year) {
	Year = year;
}

/**
 * Getter for password
 * @return password
 */
public String getPassword() {
	return Password;
}

/**
 * Setter for password
 * @param password
 */
public void setPassword(String password) {
	Password = password;
}

// -------------------------------All Methods------------------------------
/**
 * this method add key and car
 * @param key
 * @param add - the car to add
 */
public void AddCar(String key,Car add) {
	this.cars.put(key, new ArrayList<Car>());
	ArrayList<Car> c = this.cars.get(key);
	c.add(add);
	this.cars.put(key, c);
}

// -------------------------------hashCode equals & toString------------------------------
/**
 * hashCode
 */
@Override
public int hashCode() {
	return Objects.hash(BirthDate, Email, First, ID, Last, Password, Year);
}

/**
 * Check if given Customer is the same as this
 */
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	return Objects.equals(BirthDate, other.BirthDate) && Objects.equals(Email, other.Email)
			&& Objects.equals(First, other.First) && ID == other.ID && Objects.equals(Last, other.Last)
			&& Password == other.Password && Year == other.Year;
}

/**
 * Return string with all the Customer data
 */
@Override
public String toString() {
	return "Customer [First=" + First + ", Last=" + Last + ", ID=" + ID + ", Email=" + Email + ", BirthDate="
			+ BirthDate + ", Year=" + Year + ", Password=" + Password +  "]";
}

}
