/**
 * 
 */
/**
 * @author Amit
 *
 */
module ex4_207005323_207652744 {
	requires java.base;
	requires java.desktop;
}