package Entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

/**
 * This class represent a car
 * @author Amit
 *
 */
public class Car implements Serializable {
	// -------------------------------Class Members------------------------------
	/**
	 * License number of car
	 */
	private int LicenseNum;
	/**
	 * Year of manufacture 
	 */
	private int Year;
	/**
	 * model of car
	 */
	private String model;
	/**
	 * secondary model of car
	 */
	private String SecondaryModel;
	/**
	 * category of car (Mini / sedan / executive / SUV )
	 */
	private String Category;
	/**
	 * Gearbox in car
	 */
	private String Gearbox;
	/**
	 * the price for rent the car per day
	 */
	private double RentPerDay;
	/**
	 * array of dates when the car rented
	*/
	private ArrayList<String> RentedDates;

	
	// -------------------------------serialVersionUID------------------------------
	/**
	 * This is serial number for Version
	 */
	private static final long serialVersionUID = -6375975463501140840L;

	// -------------------------------Constructors------------------------------
	/**
	 * this is constructor for Car
	 * @param licenseNum
	 * @param year
	 * @param model
	 * @param secondaryModel
	 * @param category
	 * @param gearbox
	 * @param rentPerDay
	 */
	public Car(int licenseNum, int year, String model, String secondaryModel, String category, String gearbox,
			double rentPerDay) {
		super();
		this.LicenseNum = licenseNum;
		this.Year = year;
		this.model = model;
		this.SecondaryModel = secondaryModel;
		this.Category = category;
		this.Gearbox = gearbox;
		this.RentPerDay = rentPerDay;
		this.RentedDates = new ArrayList<String>();
	}
	// -----------------------------------------Setters&&Getters--------------------------------------


/**
 * Getter for LicenseNum
 * @return LicenseNum
 */
public int getLicenseNum() {
	return LicenseNum;
}
/**
 * Setter for LicenseNum
 * @param licenseNum
 */
public void setLicenseNum(int licenseNum) {
	LicenseNum = licenseNum;
}
/**
 * Getter for Year
 * @return Year
 */
public int getYear() {
	return Year;
}
/**
 * Setter for Year
 * @param year
 */
public void setYear(int year) {
	Year = year;
}
/**
 * Getter for model
 * @return model
 */
public String getModel() {
	return model;
}
/**
 * Setter for model
 * @param model
 */
public void setModel(String model) {
	this.model = model;
}
/**
 * Getter for SecondaryModel
 * @return SecondaryModel
 */
public String getSecondaryModel() {
	return SecondaryModel;
}
/**
 * Setter for SecondaryModel
 * @param secondaryModel
 */
public void setSecondaryModel(String secondaryModel) {
	SecondaryModel = secondaryModel;
}
/**
 * Getter for Category
 * @return Category
 */
public String getCategory() {
	return Category;
}
/**
 * Setter for Category
 * @param category
 */
public void setCategory(String category) {
	Category = category;
}
/**
 * Getter for Gearbox
 * @return Gearbox
 */
public String getGearbox() {
	return Gearbox;
}
/**
 * Setter for Gearbox
 * @param gearbox
 */
public void setGearbox(String gearbox) {
	Gearbox = gearbox;
}
/**
 * Getter for RentPerDay
 * @return RentPerDay
 */
public double getRentForDay() {
	return RentPerDay;
}
/**
 * Setter for RentPerDay
 * @param rentPerDay
 */
public void setRentForDay(double rentPerDay) {
	RentPerDay = rentPerDay;
}
/** Getter for Rented Dates
 * @return RentedDates
 */
public ArrayList<String> getRentedDates() {
	return RentedDates;
}
/**
 * Setter for Rented Dates
 * @param rentedDates
 */
public void setRentedDates(String rentedDates) {
	RentedDates.add(rentedDates);
}
	// -------------------------------All Methods------------------------------


	// -------------------------------hashCode equals & toString------------------------------

/**
 * return string with all the data of the car
 */
@Override
public String toString() {
	return "LicenseNum=" + LicenseNum + ", Year=" + Year + ", model=" + model + ", RentPerDay=" + RentPerDay
			;
}

/**
 * hashCode
 */
@Override
public int hashCode() {
	return Objects.hash(Category, Gearbox, LicenseNum, RentPerDay, SecondaryModel, Year, model);
}


/**
 * check if given car is the same as this car
 */
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Car other = (Car) obj;
	return Objects.equals(Category, other.Category) && Objects.equals(Gearbox, other.Gearbox)
			&& LicenseNum == other.LicenseNum
			&& Double.doubleToLongBits(RentPerDay) == Double.doubleToLongBits(other.RentPerDay)
			&& Objects.equals(SecondaryModel, other.SecondaryModel) && Year == other.Year
			&& Objects.equals(model, other.model);
}


}
