package Entities;

import java.io.Serializable;
import java.util.Objects;

/**
 * This class represent Branch
 * @author Amit
 *
 */
public class Branch implements Serializable{

// -------------------------------Class Members------------------------------
/**
 * This is number of Branch
 */
private int Number;
/**
 * this is location of Branch
 */
private String location;
/**
 * this is the opening hours
 */
private String OpeningHours;
// -------------------------------serialVersionUID------------------------------
/**
 * This is serial number for Version
 */
private static final long serialVersionUID = 3704225742461381779L;

// -------------------------------Constructors------------------------------
/**
 * This is constructor for Branch
 * @param number
 * @param location
 * @param openingHours
 */
public Branch(int number, String location, String openingHours) {
	super();
	this.Number = number;
	this.location = location;
	this.OpeningHours = openingHours;
}
// -----------------------------------------Setters&&Getters--------------------------------------
/**
 * Getter for Number
 * @return Number
 */
public int getNumber() {
	return Number;
}
/**
 * Setter for Number
 * @param number
 */
public void setNumber(int number) {
	Number = number;
}
/**
 * Getter for location
 * @return location
 */
public String getLocation() {
	return location;
}
/**
 * Setter for location
 * @param location
 */
public void setLocation(String location) {
	this.location = location;
}
/**
 * Getter for OpeningHours
 * @return OpeningHours
 */
public String getOpeninhHours() {
	return OpeningHours;
}
/**
 * Setter for OpeningHours
 * @param openighHours
 */
public void setOpeninhHours(String openighHours) {
	OpeningHours = openighHours;
}
// -------------------------------All Methods------------------------------


// -------------------------------hashCode equals & toString------------------------------
/**
 * this method return string with all the hashCode data
 */
@Override
public String toString() {
	return "Branch [Number=" + Number + ", location=" + location + ", OpeningHours=" + OpeningHours + "]";
}
/**
 * hashCode
 */
@Override
public int hashCode() {
	return Objects.hash(Number, OpeningHours, location);
}
/**
 * this method check if given Branch is the same as this
 */
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Branch other = (Branch) obj;
	return Number == other.Number && OpeningHours == other.OpeningHours && Objects.equals(location, other.location);
}

}
