package Screens;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Users.Manager;

/**
 * This class represent a Customer Screen
 * @author Amit
 *
 */
public class CustomerScreen extends JFrame implements ActionListener , Serializable {

	/**
	 * This is serial number for Version
	 */	
	private static final long serialVersionUID = 9076273478010441258L;
	private Manager Admin;
	private JLabel ManuCustomerlbl;
	private JButton ShowBranchbtn;
	private JButton ShowRentCar;
	private JButton LogOutbtn;
	private JLabel iconlbl;
	/**
	 * this is constructor for Customer screen frame
	 * @param admin
	 * @param email 
	 */
	public CustomerScreen(Manager admin, String email) {
		super("Welcome Customer to Ruppin Rent");
		Admin = admin;
		Admin.Save(Admin);
		iconlbl = new JLabel();
		ManuCustomerlbl = new JLabel("Choose your option:");
		ShowBranchbtn = new JButton("Show Branches");
		ShowRentCar = new JButton("Show Available Rent Cars");
		LogOutbtn = new JButton("Log Out");
		
		ShowBranchbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ex) {
				if(Admin.getBranchs().size() == 0)
				{
					JOptionPane.showMessageDialog(null, "There is not branch exists", "Error", JOptionPane.PLAIN_MESSAGE);
					return ;
				}
				SearchBranch S = new SearchBranch(Admin,email);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}

		});
		ShowRentCar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ex) {
				if(CheckAvailable() == true)
				{
					SearchCar S = new SearchCar(Admin,email);
					S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
				    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
				    S.setLocation(x, y);
					S.setVisible(true);
					dispose();
					return;
				}
				JOptionPane.showMessageDialog(null, "There is not available cars", "Error", JOptionPane.PLAIN_MESSAGE);
				return ;
			}


		});
		LogOutbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ex) {
				SignInORegister S = new SignInORegister(Admin);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}

		});
		initializeIcon();
		initialize();

	}
	private void initializeIcon() {
		this.iconlbl.setIcon(new ImageIcon("icon//Customer.png"));
		Dimension size = iconlbl.getPreferredSize(); //Gets the size of the image
		iconlbl.setBounds(50, 30, size.width, size.height); //Sets the location of the image
	}
	/**
	 * add icon
	 * @return JPanel
	 */
	private JPanel addIcon() {
		JPanel p = new JPanel(new FlowLayout());
		p.add(iconlbl);
		return p;
	}
	/**
	 * this method check if the car is available
	 * @return true if available, false other wise
	 */
	private boolean CheckAvailable() {
		if(Admin.getCars().size() > 0)
		{
			return true;
		}
		return false;
	}
	/**
	 * add grdi
	 * @return JPanel
	 */
	private JPanel addGrid() {
		JPanel p = new JPanel(new GridLayout(0,3));
		p.add(new JLabel(""));
		p.add(ManuCustomerlbl);
		return p;
	}
	
	/**
	 * add buttons
	 * @return JPanel
	 */
	private JPanel addButtons() {
		
		JPanel p=new JPanel(new FlowLayout()); 
		p.add(ShowBranchbtn);
		p.add(ShowRentCar);
		p.add(LogOutbtn);
		return p;
	}
	
	/**
	 * initialize
	 */
	private void initialize() {
		
		setLayout(new BorderLayout());
		add(addIcon(),BorderLayout.NORTH);
		add(addGrid(),BorderLayout.CENTER);
		add(addButtons(),BorderLayout.SOUTH);
		pack();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
