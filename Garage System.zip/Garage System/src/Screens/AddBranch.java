package Screens;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
//import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Entities.Branch;
import Users.Manager;

/**
 * This class represent Screen for adding new Branch
 * @author Amit
 *
 */
public class AddBranch extends JFrame implements ActionListener , Serializable{
	private Manager Admin;
	/**
	 * This is serial number for Version
	 */
	private static final long serialVersionUID = 2047619357329087526L;
	private JLabel Numberlbl;
	private Choice NumberCh;
	private JLabel Locationlbl;
	private JTextField Locationtxt;
	private JLabel OpeningHourslbl;
	private Choice HourOCh;
	private Choice MinuteOCh;
	private JLabel ClosingHourslbl;
	private Choice HourCCh;
	private Choice MinuteCCh;
	private JButton Finishbtn;
	private JButton Cancelbtn;
	
	private JLabel ErrorNumberlbl;
	private JLabel ErrorLocationlbl;
	private JLabel ErrorOpeninglbl;
	private JLabel ErrorClosinglbl;

	/**
	 * Constructor for AddBranch Frame
	 * @param admin
	 */
	public AddBranch(Manager admin) {
		super("Adding New Branch For Ruppin Rent");
		Admin = admin;
		Admin.Save(Admin);
		Numberlbl = new JLabel("Branch number: ");
		NumberCh = new Choice();
		Locationlbl = new JLabel("Branch location: ");
		Locationtxt = new JTextField(20);
		OpeningHourslbl = new JLabel("Opining Hours: ");
		HourOCh = new Choice();
		MinuteOCh = new Choice();
		ClosingHourslbl = new JLabel("Closing Hours: ");
		HourCCh = new Choice();
		MinuteCCh = new Choice();

		Finishbtn = new JButton("Finish");
		Cancelbtn = new JButton("Cancel");
		Finishbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(Validation() == false) {
					return;
				}
				else {
					Locationtxt.setBackground(Color.GREEN);
					AddNewBranch();
					//  pop up massage that says : "Added successfully"
					JOptionPane.showMessageDialog(null, "Added successfully!", "Rupin Rent", JOptionPane.PLAIN_MESSAGE);
					ManagerScreen S = new ManagerScreen(Admin);
					S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
				    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
				    S.setLocation(x, y);
					S.setVisible(true);
					dispose();
				}
				
			}
		});
		Cancelbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ManagerScreen S = new ManagerScreen(Admin);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}
		});
		
		
		ErrorNumberlbl = new JLabel("");
		ErrorLocationlbl = new JLabel("");
		ErrorOpeninglbl = new JLabel("");
		ErrorClosinglbl = new JLabel("");
		
		initializeOpeningHours();
		initializeClosingHours();
		initializeBranchNumber();
		initialize();
		
	}
	/**
	 * initialize Closing Hours
	 */
	private void initializeClosingHours() {
		for (int i = 0 ; i < 25 ; i++) {
			HourCCh.add(Integer.toString(i));
		}
		for (int i = 0 ; i < 60 ; i++) {
			MinuteCCh.add(Integer.toString(i));
		}
		
	}
	/**
	 * initialize Opening Hours
	 */
	private void initializeOpeningHours() {
		for (int i = 0 ; i < 25 ; i++) {
			HourOCh.add(Integer.toString(i));
		}
		for (int i = 0 ; i < 60 ; i++) {
			MinuteOCh.add(Integer.toString(i));
		}
		
	}
	/**
	 * initialize Branch Number
	 */
	private void initializeBranchNumber() {
		for(int i = 1 ; i < 1001 ; i++) {
			NumberCh.add(Integer.toString(i));
		}
	}
	/**
	 * add date opening
	 * @return JPanel
	 */
	private JPanel AddDateO() {
		JPanel p = new JPanel(new FlowLayout());
		p.add(HourOCh);
		p.add(new JLabel(" : "));
		p.add(MinuteOCh);
		return p;
	}
	/**
	 * add date Close
	 * @return
	 */
	private JPanel AddDateC() {
		JPanel p = new JPanel(new FlowLayout());
		p.add(HourCCh);
		p.add(new JLabel(" : "));
		p.add(MinuteCCh);
		return p;
	}
	/**
	 * add grid
	 * @return JPanel
	 */
	private JPanel addGrid() {
		JPanel p = new JPanel(new GridLayout(0,3));
		p.add(Locationlbl);
		p.add(Locationtxt);
		p.add(ErrorLocationlbl);
		p.add(Numberlbl);
		p.add(NumberCh);
		p.add(ErrorNumberlbl);
		p.add(OpeningHourslbl);
		p.add(AddDateO());
		p.add(ErrorOpeninglbl);
		p.add(ClosingHourslbl);
		p.add(AddDateC());
		p.add(ErrorClosinglbl);
		return p;
	}
	
	/**
	 * add buttons
	 * @return JPanel
	 */
	private JPanel addButtons() {
		
		JPanel p=new JPanel(new FlowLayout()); 
		p.add(Finishbtn);
		p.add(Cancelbtn);
		return p;
	}
	
	/**
	 * initialize
	 */
	private void initialize() {
		
		setLayout(new BorderLayout());
		add(addGrid(),BorderLayout.NORTH);
		add(addButtons(),BorderLayout.CENTER);
		setSize(800,200);
	}
	
	/**
	 * this method check validation of the input
	 * @return
	 */
	private boolean Validation() {
		int count = 0;
		if(CheckLocation() == false)
		{
			count++;
		}
		if(CheckNumber() == false) {
			count++;
		}
		if(CheckOpeningHours() == false) {
			count++;
		}
		if(count > 0) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * this method check location validation
	 * @return true if valid, false otherwise
	 */
	private boolean CheckLocation() {
		if(this.Locationtxt.getText().isEmpty() || this.Locationtxt.getText().length() == 0 || this.Locationtxt.getText() == "") {
			this.ErrorLocationlbl.setText("Insert location");
			this.Locationtxt.setBackground(Color.RED);
			return false;
		}
		for (int i = 0; i < Locationtxt.getText().length(); i++) {
	        char ch = Locationtxt.getText().charAt(i);
	        if (!Character.isLetter(ch) && ch != ' ') {
	        	ErrorLocationlbl.setText("Name should contain only chars and spaces");
	        	Locationtxt.setBackground(Color.RED);
	        	return false;
	        }
	    }
		ErrorLocationlbl.setText(null);
		Locationtxt.setBackground(Color.GREEN);
		return true;
	}
	/**
	 * this method check if the number if valid
	 * @return true if valid, false otherwise
	 */
	private boolean CheckNumber() {
		for(Branch bra : Admin.getBranchs())
		{
			if (bra.getNumber() == Integer.parseInt(this.NumberCh.getSelectedItem()))
			{
				this.ErrorNumberlbl.setText("Number already exists in the system");
				this.NumberCh.setBackground(Color.RED);
				return false;
			}
		}
		this.ErrorNumberlbl.setText(null);
		this.NumberCh.setBackground(Color.GREEN);
		return true;
	}
	/**
	 * this method check if opening hours is valid
	 * @return true if valid, false otherwise
	 */
	private boolean CheckOpeningHours() {
		if (Integer.parseInt(this.HourOCh.getSelectedItem()) > Integer.parseInt(this.HourCCh.getSelectedItem())) {
			this.ErrorClosinglbl.setText("The Closing hours need to be affter the opening hours");
			this.HourCCh.setBackground(Color.RED);
			this.MinuteCCh.setBackground(null);
			return false;
		}
		if (Integer.parseInt(this.HourOCh.getSelectedItem()) == Integer.parseInt(this.HourCCh.getSelectedItem())) {
			if (Integer.parseInt(this.MinuteOCh.getSelectedItem()) >= Integer.parseInt(this.MinuteCCh.getSelectedItem())) {
				this.ErrorClosinglbl.setText("The Closing mins need to be affter the opening mins");
				this.MinuteCCh.setBackground(Color.RED);
				this.HourCCh.setBackground(Color.GREEN);
				return false;
			}
		}
		this.ErrorClosinglbl.setText(null);
		this.MinuteCCh.setBackground(Color.GREEN);
		this.HourCCh.setBackground(Color.GREEN);
		this.MinuteOCh.setBackground(Color.GREEN);
		this.HourOCh.setBackground(Color.GREEN);
		return true;
	}
	/**
	 * this method add new branch
	 */
	private void AddNewBranch() {
		String hourO;
		String minO;
		String hourC;
		String minC;
		if(Integer.parseInt(this.HourOCh.getSelectedItem()) < 10) {
			hourO = 0 + this.HourOCh.getSelectedItem();
		}
		else
			hourO = this.HourOCh.getSelectedItem();
		if(Integer.parseInt(this.MinuteOCh.getSelectedItem()) < 10)
		{
			minO = 0 + this.MinuteOCh.getSelectedItem();
		}
		else
			minO = this.MinuteOCh.getSelectedItem();
		if(Integer.parseInt(this.HourCCh.getSelectedItem()) < 10)
		{
			hourC = 0 + this.HourCCh.getSelectedItem();
		}
		else
			hourC = this.HourCCh.getSelectedItem();
		if(Integer.parseInt(this.MinuteCCh.getSelectedItem()) < 10)
		{
			minC = 0 + this.MinuteCCh.getSelectedItem();
		}
		else
			minC = this.MinuteCCh.getSelectedItem();						
	
		Branch newBracn = new Branch(Integer.parseInt(this.NumberCh.getSelectedItem()),this.Locationtxt.getText(),hourO + ":" + minO + "-" + hourC + ":" + minC);
		Admin.AddBranch(newBracn);
		// need to check down here
		Admin.AddBranchToCarPerStore(Integer.parseInt(this.NumberCh.getSelectedItem()));
		//Admin.getCarsPerStore().put(Integer.parseInt(this.NumberCh.getSelectedItem()),new ArrayList<Car>());

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
