package Screens;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Users.Customer;
import Users.Manager;

/**
 * this method represent Sign in frame
 * @author Amit
 *
 */
public class SignIn extends JFrame implements ActionListener , Serializable{
	private Manager Admin;

	/**
	 * This is serial number for Version
	 */
	private static final long serialVersionUID = 3287476709335590862L;

	private JLabel Emaillbl;
	private JTextField Emailtxt;
	private JLabel Passwordlbl;
	private JPasswordField  Passwordtxt;	
	private JButton LogInbtn;
	private JButton Cancelbtn;
	
	
	private JLabel ErrorEmail;
	private JLabel ErrorPassword;
	/**
	 * this is constructor for Sign In frame
	 * @param admin
	 */
	public SignIn(Manager admin) {
		super("Sign In for Ruppin Rent");
		Admin = admin;
		Admin.Save(Admin);
		Emaillbl = new JLabel("Enter Email: ");
		Emailtxt = new JTextField(20);
		Passwordlbl = new JLabel("Enter Passowrd: ");
		Passwordtxt = new JPasswordField();
		Passwordtxt.setEchoChar('*');
		LogInbtn = new JButton("Log In");
		Cancelbtn = new JButton("Cancel");
		
		LogInbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//Something Wrong
				if(CheckLoggingIn() == 0) {
					return;
				}
				//Manager
				if(CheckLoggingIn() == 1 ) {
					ManagerScreen S = new ManagerScreen(Admin);
					S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
				    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
				    S.setLocation(x, y);
					S.setVisible(true);
					dispose();
				}
				//Customer
				if(CheckLoggingIn() == 2 ) {
		    		CustomerScreen S = new CustomerScreen(Admin,Emailtxt.getText());
					S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
				    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
				    S.setLocation(x, y);
					S.setVisible(true);
			    	dispose();
				}
				
			}
			
		});
		Cancelbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				SignInORegister S = new SignInORegister(Admin);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}
		});
		ErrorEmail = new JLabel("");
		ErrorPassword = new JLabel("");
		initialize();
	}
	
	/**
	 * initialize
	 */
	private void initialize() {
		setLayout(new BorderLayout());
		add(addGrid(),BorderLayout.NORTH);
		add(addButtons(),BorderLayout.CENTER);
		pack();
	}
	/**
	 * add grid
	 * @return JPanel
	 */
	private JPanel addGrid() {
		JPanel p = new JPanel(new GridLayout(0,3));
		p.add(Emaillbl);
		p.add(Emailtxt);
		p.add(ErrorEmail);
		p.add(Passwordlbl);
		p.add(Passwordtxt);
		p.add(ErrorPassword);
		return p;
	}
	
	/**
	 * add buttons
	 * @return JPanel
	 */
	private JPanel addButtons() {
		
		JPanel p=new JPanel(new FlowLayout()); 
		p.add(this.LogInbtn);
		p.add(this.Cancelbtn);
		return p;
	}
	
	/**
	 * This method CheckLoggingIn and check who loged in(manager or customer)
	 * @return 0 if something wrong, 1 if is manager, 2 if is customer
	 */
	private int CheckLoggingIn() {
		int count = 0;
		if (CheckPass() == false)
		{
			count++;
		}
		if (CheckEmail() == false) {
			count++;
		}

		if(this.Emailtxt.getText().equals("Admin@Admin.com") && new String(this.Passwordtxt.getPassword()).equals("Admin123")) {
			return 1;
		}
		for (Customer cus : Admin.getCustomers()) {
			if(cus.getEmail().equals(this.Emailtxt.getText()))
			{
				if (cus.getPassword().equals(new String(this.Passwordtxt.getPassword()))) {
					
					return 2;
				}
			}
		}
		if(count > 0) {
			return 0;
		}
		return 0;
	}
	/**
	 * this method check if pass is valid 
	 * @return true if valid, false other wise
	 */
	private boolean CheckPass() {
		
		if(new String(this.Passwordtxt.getPassword()).equals(""))
		{
			this.ErrorPassword.setText("Insert Password");
			this.Passwordtxt.setBackground(Color.RED);
			return false;
		}
		for (Customer cus : Admin.getCustomers()) {
			if(cus.getEmail().equals(this.Emailtxt.getText()))
			{
				if (cus.getPassword().equals(new String(this.Passwordtxt.getPassword()))) {
					this.ErrorPassword.setText(null);
					this.Passwordtxt.setBackground(Color.GREEN);
					return true;
				}
			}
		}
		this.ErrorPassword.setText("Password is not correct");
		this.Passwordtxt.setBackground(Color.RED);
		return false;
	}
    /**
     * String and pattern for CheckEmail
     */
    private static final String EMAIL_REGEX = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);

	/**
	 * this method check verify of Email
	 * @return true if ok, false otherwise
	 */
	/**
	 * this method check if email is valid and exists
	 * @return true if valid, false other wise
	 */
	private boolean CheckEmail() {
	    if (this.Emailtxt.getText() == null || this.Emailtxt.getText().length() == 0) {
	    	this.ErrorEmail.setText("Insert Email");
	    	this.Emailtxt.setBackground(Color.RED);
	    	return false;
	    }
		Matcher matcher = EMAIL_PATTERN.matcher(this.Emailtxt.getText());
        if(!matcher.matches()) {
        	this.ErrorEmail.setText("Email Isn't legal");
        	this.Emailtxt.setBackground(Color.RED);
        	return false;
        }
		//if(this.Emailtxt.getText().equals("Admin@Admin.com")){
		if(this.Emailtxt.getText().equals(Admin.getEmail())){
			 this.ErrorEmail.setText(null);
		     this.Emailtxt.setBackground(Color.GREEN);
		     //if( new String(this.Passwordtxt.getPassword()).equals("Admin123")) {
		     if( new String(this.Passwordtxt.getPassword()).equals(Admin.getPassoword())) {
					this.ErrorPassword.setText(null);
					this.Passwordtxt.setBackground(Color.GREEN);
		     }
		     return true;
		}
		for (Customer cus : Admin.getCustomers()) {
			if(cus.getEmail().equals(this.Emailtxt.getText()))
			{
				 this.ErrorEmail.setText(null);
			     this.Emailtxt.setBackground(Color.GREEN);
			     return true;
			}
		}
        this.ErrorEmail.setText("Email not register");
        this.ErrorPassword.setText(null);
        this.Emailtxt.setBackground(Color.RED);
        return false;
        
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
