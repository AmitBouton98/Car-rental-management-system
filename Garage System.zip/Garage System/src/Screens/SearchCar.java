package Screens;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Entities.Branch;
import Entities.Car;
import Users.Customer;
import Users.Manager;

/**
 * this method represent Search Car frame for customer
 * @author Amit
 *
 */
public class SearchCar extends JFrame implements ActionListener , Serializable {
	private Manager Admin;
	/**
	 * serial number
	 */
	private static final long serialVersionUID = -268543765408187288L;
	private JLabel Branchlbl;
	private Choice BranchCh;
	private JLabel Categorylb;
	private Choice CategoryCh;
	private JLabel Modellbl;
	private JTextField Modeltxt;
	private JLabel Yearlbl;
	private JTextField Yeartxt;
	private JLabel Pricelbl;
	private JTextField Pricetxt;
	private JLabel GearBoxlbl;
	private Choice GearBoxCh;
	
	private JLabel ErrorBranchlbl;
	private JLabel ErrorCategorylbl;
	private JLabel ErrorModellbl;
	private JLabel ErrorYearlbl;
	private JLabel ErrorPricelbl;
	private JLabel ErrorGearBoxlbl;
	
	private JButton Searchbtn;
	private JButton Exitbtn;
	private JButton Clearbtn;

	
	private Choice SelectCarCh;
	private JButton Confirmbtn;
	
	
	private JLabel Datelbl;
	private Choice YearToRentCh;
	private Choice MonthToRentCh;
	private Choice DayToRentCh;
	private JLabel ErrorDatelbl;
	
	private String Email;
	/**
	 * this is constructor for Search car frame
	 * @param admin
	 * @param email 
	 */
	public SearchCar(Manager admin, String email) {
		super("Search car");
		Admin = admin;
		Email = email;
		Branchlbl = new JLabel("Branch number: ");
		BranchCh = new Choice();
		Categorylb = new JLabel("Category: ");
		CategoryCh = new Choice();
		Modellbl = new JLabel("Model: ");
		Modeltxt = new JTextField(20);
		Yearlbl = new JLabel("Year of prodation: ");
		Yeartxt = new JTextField(20);
		Pricelbl = new JLabel("Price: ");
		Pricetxt = new JTextField(20);
		GearBoxlbl = new JLabel("GearBox: ");
		GearBoxCh = new Choice();
		
		ErrorBranchlbl = new JLabel("");
		ErrorCategorylbl = new JLabel("");
		ErrorModellbl = new JLabel("");
		ErrorYearlbl = new JLabel("");
		ErrorPricelbl = new JLabel("");
		ErrorGearBoxlbl = new JLabel("");
		
		Searchbtn = new JButton("Search");
		Exitbtn = new JButton("Exit");
		
		Datelbl = new JLabel("Date to rent:");
		YearToRentCh = new Choice();
		MonthToRentCh = new Choice();
		DayToRentCh = new Choice();
		ErrorDatelbl = new JLabel("");
		
		Clearbtn = new JButton("Clear");
		Clearbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Clear();
				return;
			}
			
		});
		Searchbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SelectCarCh.removeAll();
				if (Validation() == false)
				{
					JOptionPane.showMessageDialog(null, "Couldnt find car", "Problem", JOptionPane.PLAIN_MESSAGE);
					Clear();
					SelectCarCh.setVisible(false);
					Confirmbtn.setVisible(false);
				}
				else {
					ShowCar();
					return;
				}
				
			}
		});
		Exitbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CustomerScreen S = new CustomerScreen(Admin,email);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
				
			}
			
		});
		Confirmbtn = new JButton("Confirm");
		Confirmbtn.setVisible(false);
		SelectCarCh = new Choice();
		SelectCarCh.setVisible(false);
		Confirmbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Rented!", "Rupin Rent", JOptionPane.PLAIN_MESSAGE);
				RentCar();
				CustomerScreen S = new CustomerScreen(Admin,email);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
				
			}
			
		});
		initializeDate();
		initializeCategory();
		initializeBranch();
		initializeGearBox();
		initialize();
	}
	/**
	 * this method rent car
	 */
	private void RentCar() {
		String Choose = this.SelectCarCh.getSelectedItem();
		// need to check down here
	    for(Car car : Admin.getCarsPerStore().get(Integer.parseInt(BranchCh.getSelectedItem()))) {
	    	if(car.toString().equals(Choose)) {
	    		car.setRentedDates(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem());
	    		this.SelectCarCh.remove(this.SelectCarCh.getSelectedIndex());
	    		for(Customer cus : Admin.getCustomers())
	    		{
	    			if(cus.getEmail().equals(Email)) {
	    				cus.AddCar(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem(), car);
	    				//cus.getCars().put(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem(), car);
	    			}
	    		}
	    		return;
	    	}
	    }
	    	
	}
	/**
	 * this method clear the screen
	 */
	private void Clear() {
		ErrorBranchlbl.setText("");
		ErrorCategorylbl.setText("");
		ErrorModellbl.setText("");
		ErrorYearlbl.setText("");
		ErrorPricelbl.setText("");
		ErrorGearBoxlbl.setText("");
		ErrorDatelbl.setText("");
		BranchCh.setBackground(Color.WHITE);
		CategoryCh.setBackground(Color.WHITE);
		Modeltxt.setBackground(Color.WHITE);
		Yeartxt.setBackground(Color.WHITE);
		Pricetxt.setBackground(Color.WHITE);
		GearBoxCh.setBackground(Color.WHITE);
		YearToRentCh.setBackground(Color.WHITE);
		MonthToRentCh.setBackground(Color.WHITE);
		DayToRentCh.setBackground(Color.WHITE);
		Modeltxt.setText("");
		Yeartxt.setText("");
		Pricetxt.setText("");
		SelectCarCh.removeAll();
		SelectCarCh.setVisible(false);
		Confirmbtn.setVisible(false);
	}
	/**
	 * this method set car selected visible to true
	 */
	private void ShowCar() {
		SelectCarCh.setSize(400, 400);
		SelectCarCh.setVisible(true);
		Confirmbtn.setVisible(true);
	}
	/**
	 * this method check validation
	 * @return true if there any car with this limited selection
	 */
	private boolean Validation() {
		int count = 0;
		if(CheckYear() == true)
		{
			count++;
		}
		if(CheckPrice() == true) {
			count++;
		}
		if(CheckCategory() == true) {
			count++;
		}
		if(CheckGearBox() == true) {
			count++;
		}
		if(CheckModel() == true) {
			count++;
		}
		if(count > 0) {
			return true;
		}
		else {
			return false;
		}
	}
	/**
	 * this method check if there any car with this model
	 * @return true if valid, false other wise
	 */
	private boolean CheckModel() {
		int count = 0;
	    for(Car c : Admin.getCarsPerStore().get(Integer.parseInt(BranchCh.getSelectedItem())))
	    {
	    	if((c.getModel().equals(this.Modeltxt.getText())||c.getSecondaryModel().equals(this.Modeltxt.getText()))&& !c.getRentedDates().contains(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem())){
	    		for(int j = 0; j < this.SelectCarCh.getItemCount() ; j++) {
	    			if(this.SelectCarCh.getItem(j).equals(c.toString()))
	    			{
	    	    		this.ErrorModellbl.setText(null);
	    	        	this.Modeltxt.setBackground(Color.GREEN);
	    				return true;
	    			}
	    		}
	    		this.SelectCarCh.add(c.toString());
	    		this.ErrorModellbl.setText(null);
	        	this.Modeltxt.setBackground(Color.GREEN);
	        	count++;
	    	}
	    }
	    if(count > 0) {
	        return true;
	    }
	    else {
        	this.Modeltxt.setBackground(Color.RED);
	    	return false;
	    }
	}
	/**
	 * this method check if there any car with this gearbox
	 * @return true if valid, false other wise
	 */
	private boolean CheckGearBox() {
		int count = 0;
	    for(Car c : Admin.getCarsPerStore().get(Integer.parseInt(BranchCh.getSelectedItem())))
	    {
	    	if(c.getGearbox().equals(this.GearBoxCh.getSelectedItem())&& !c.getRentedDates().contains(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem())){
	    		for(int j = 0; j < this.SelectCarCh.getItemCount() ; j++) {
	    			if(this.SelectCarCh.getItem(j).equals(c.toString()))
	    			{
	    				this.ErrorGearBoxlbl.setText(null);
	    				this.GearBoxCh.setBackground(Color.GREEN);
	    				return true;
	    			}
	    		}
	    		this.SelectCarCh.add(c.toString());
	    		this.ErrorGearBoxlbl.setText(null);
	        	this.GearBoxCh.setBackground(Color.GREEN);
	        	count++;
	    	}
	    }
	    if(count > 0) {
	        return true;
	    }
	    else {
        	this.GearBoxCh.setBackground(Color.RED);
	    	return false;
	    }

	}
	
	/**
	 * this method check if there any category with this selection
	 * @return true if exists, false otherwise
	 */
	private boolean CheckCategory() {
		int count = 0;
	    for(Car c : Admin.getCarsPerStore().get(Integer.parseInt(BranchCh.getSelectedItem())))
	    {
	    	if(c.getCategory().equals(this.CategoryCh.getSelectedItem())&& !c.getRentedDates().contains(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem())){
	    		for(int j = 0; j < this.SelectCarCh.getItemCount() ; j++) {
	    			if(this.SelectCarCh.getItem(j).equals(c.toString()))
	    			{
	    	    		this.ErrorCategorylbl.setText(null);
	    	        	this.CategoryCh.setBackground(Color.GREEN);
	    				return true;
	    			}
	    		}
	    		this.SelectCarCh.add(c.toString());
	    		this.ErrorCategorylbl.setText(null);
	        	this.CategoryCh.setBackground(Color.GREEN);
	        	count++;
	    	}
	    }
	    if(count > 0) {
	        return true;
	    }
	    else {
        	this.CategoryCh.setBackground(Color.RED);
	    	return false;
	    }
	}
	/**
	 * this method check if there any with this price
	 * @return true if exists, false otherwise
	 */
	private boolean CheckPrice() {
		if(this.Pricetxt.getText().isEmpty() || this.Pricetxt.getText().length() == 0 || this.Pricetxt.getText() == "") {
			this.ErrorPricelbl.setText("Insert Price");
			this.Pricetxt.setBackground(Color.RED);
			return false;
		}
	    for (int i = 0; i < this.Pricetxt.getText().length(); i++) {
	        char ch = this.Pricetxt.getText().charAt(i);
	        if(ch == '.')
	        {
	        	for (i = i+1 ; i < this.Pricetxt.getText().length() ; i++) {
	    	        ch = this.Pricetxt.getText().charAt(i);
	    	        if (!Character.isDigit(ch)) {
	    		        this.ErrorPricelbl.setText("Price should contain only digits and one point");
	    		        this.Pricetxt.setBackground(Color.RED);
	    		         return false;
	    		        }
	        	}
	        }
	        if (!Character.isDigit(ch)) {
	        this.ErrorPricelbl.setText("Price should contain only digits");
	        this.Pricetxt.setBackground(Color.RED);
	         return false;
	        }
	    }
	    int count = 0;
	    for(Car c : Admin.getCarsPerStore().get(Integer.parseInt(BranchCh.getSelectedItem()))) {
	    	if(c.getRentForDay() == Double.parseDouble(this.Pricetxt.getText()) && !c.getRentedDates().contains(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem())){
	    		for(int j = 0; j < this.SelectCarCh.getItemCount() ; j++) {
	    			if(this.SelectCarCh.getItem(j).equals(c.toString()))
	    			{
	    	    		this.ErrorPricelbl.setText(null);
	    	        	this.Pricetxt.setBackground(Color.GREEN);
	    				return true;
	    			}
	    		}
	    		this.SelectCarCh.add(c.toString());
	    		this.ErrorPricelbl.setText(null);
	        	this.Pricetxt.setBackground(Color.GREEN);
	    		count ++;
	    	}
	    }
	    if(count > 0) {
	        return true;
	    }
	    else {
        	this.Pricetxt.setBackground(Color.RED);
	    	return false;
	    }


	}
	/**
	 * this method check if there any car with this year 
	 * @return true if exists, false otherwise
	 */
	private boolean CheckYear() {
		 if (this.Yeartxt.getText() == null || this.Yeartxt.getText().length() == 0) {
		    	this.ErrorYearlbl.setText("Insert Year");
		    	this.Yeartxt.setBackground(Color.RED);
		    	return false;
		    }
		    for (int i = 0; i < this.Yeartxt.getText().length(); i++) {
		        char ch = this.Yeartxt.getText().charAt(i);
		        if (!Character.isDigit(ch)) {
		        	this.ErrorYearlbl.setText("Year should contain only digits");
		        	this.Yeartxt.setBackground(Color.RED);
		            return false;
		        }
		    }
		    if(Integer.parseInt(this.Yeartxt.getText()) > 2023) {
	        	this.ErrorYearlbl.setText("Year cant be in the future");
	        	this.Yeartxt.setBackground(Color.RED);
	            return false;
		    }
		    int count = 0;
		    for(Car c : Admin.getCarsPerStore().get(Integer.parseInt(BranchCh.getSelectedItem())))
		    {
		    	if(c.getYear() == Integer.parseInt(this.Yeartxt.getText()) && !c.getRentedDates().contains(this.DayToRentCh.getSelectedItem()+"/"+this.MonthToRentCh.getSelectedItem()+"/"+this.YearToRentCh.getSelectedItem())){
		    		for(int j = 0; j < this.SelectCarCh.getItemCount() ; j++) {
		    			if(this.SelectCarCh.getItem(j).equals(c.toString()))
		    			{
				    		this.ErrorYearlbl.setText(null);
				        	this.Yeartxt.setBackground(Color.GREEN);
		    				return true;
		    			}
		    		}
		    		this.SelectCarCh.add(c.toString());
		    		this.ErrorYearlbl.setText(null);
		        	this.Yeartxt.setBackground(Color.GREEN);
		    		count++;
		    	}
		    }
		    if(count > 0) {
		        return true;
		    }
		    else {
	        	this.Yeartxt.setBackground(Color.RED);
		    	return false;
		    }

	}
	
	/**
	 *  initialize category Choice
	 */
	private void initializeCategory() {
		this.CategoryCh.add("Mini");
		this.CategoryCh.add("Sadan");
		this.CategoryCh.add("Manager");
		this.CategoryCh.add("SUV");
	}
	/**
	 *  initialize Branch Choice
	 */
	private void initializeBranch() {
		for(Branch bra : Admin.getBranchs())
		{
			this.BranchCh.add(Integer.toString(bra.getNumber()));
		}
	}
	/**
	 *  initialize Gearbox Choice
	 */
	private void initializeGearBox() {
		this.GearBoxCh.add("Manual");
		this.GearBoxCh.add("Automatic");
	}
	/**
	 * this method add grid
	 * @return JPanel p
	 */
	private JPanel addGrid() {
		JPanel p = new JPanel(new GridLayout(0,3));
		p.add(Branchlbl);
		p.add(BranchCh);
		p.add(ErrorBranchlbl);
		p.add(Categorylb);
		p.add(CategoryCh);
		p.add(ErrorCategorylbl);
		p.add(Modellbl);
		p.add(Modeltxt);
		p.add(ErrorModellbl);
		p.add(Yearlbl);
		p.add(Yeartxt);
		p.add(ErrorYearlbl);
		p.add(Pricelbl);
		p.add(Pricetxt);
		p.add(ErrorPricelbl);
		p.add(GearBoxlbl);
		p.add(GearBoxCh);
		p.add(ErrorGearBoxlbl);
		p.add(Datelbl);
		p.add(addDate());
		p.add(ErrorDatelbl);
		return p;
	}
	/**
	 * add date
	 * @return JPanel
	 */
	private JPanel addDate() {
		JPanel  p = new JPanel(new FlowLayout());
		p.add(new JLabel("Day:"));
		p.add(DayToRentCh);
		p.add(new JLabel("Month:"));	
		p.add(MonthToRentCh);	
		p.add(new JLabel("Year:"));
		p.add(YearToRentCh);
		return p;
	}
	/**
	 * initialize date
	 */
	private void initializeDate() {
		for(int i = 1 ; i < 32; i++) {
			this.DayToRentCh.add(Integer.toString(i));
		}
		for(int i = 1 ; i < 13; i++) {
			this.MonthToRentCh.add(Integer.toString(i));
		}
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		for(int i = 1 ; i < 101; i++) {
			this.YearToRentCh.add(Integer.toString(year + i));
		}
		return;
	}
	/**
	 * this method add Buttons
	 * @return JPanel p
	 */
	private JPanel addButtons() {
		JPanel p=new JPanel(new GridLayout(0,4)); 
		p.add(Clearbtn);
		p.add(Searchbtn);
		p.add(Exitbtn);
		p.add(new JLabel(""));
		p.add(new JLabel(""));
		p.add(this.SelectCarCh);
		p.add(this.Confirmbtn);
		p.add(new JLabel(""));
		return p;
	}
	/**
	 * initialize and pack
	 */
	private void initialize() {
		
		setLayout(new BorderLayout());
		add(addGrid(),BorderLayout.NORTH);
		add(addButtons(),BorderLayout.CENTER);
		this.setSize(Toolkit.getDefaultToolkit().getScreenSize().width, 300);
		}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
