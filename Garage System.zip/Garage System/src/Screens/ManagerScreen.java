package Screens;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Users.Manager;

/**
 * This class represent Manager Screen
 * @author Amit
 *
 */
public class ManagerScreen extends JFrame implements ActionListener , Serializable {
	private Manager Admin;
	/**
	 * This is serial number for Version
	 */
	private static final long serialVersionUID = -6375280867839403162L;
	private JLabel txt;
	private JButton AddBranchbtn;
	private JButton AddCarbtn;
	private JButton LogOutbtn;
	private JLabel iconlbl;
	/**
	 * thisi s constructor for Manager screen frame
	 * @param admin
	 */
	public ManagerScreen(Manager admin) {
		super("Welcome Manager to Ruppin Rent");
		Admin = admin;
		Admin.Save(Admin);
		iconlbl = new JLabel();
		txt = new JLabel("Choose your option: ");
		AddBranchbtn = new JButton("Add Branch");
		AddCarbtn = new JButton("Add Car and link");
		LogOutbtn = new JButton("Log Out");
		
		AddBranchbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				AddBranch S = new AddBranch(Admin);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}
			
		});
		AddCarbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(CheckIfBranchExist()) {
					AddCar S = new AddCar(Admin);
					S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
				    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
				    S.setLocation(x, y);
					S.setVisible(true);
					dispose();
				}
				else {
					JOptionPane.showMessageDialog(null, "There is not Branch exists", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
			}
			
		});
		LogOutbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SignInORegister S = new SignInORegister(Admin);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
				
			}
			
		});
		initializeIcon();
		initialize();
	}
	private void initializeIcon() {
		this.iconlbl.setIcon(new ImageIcon("icon//Manager.png"));
		Dimension size = iconlbl.getPreferredSize(); //Gets the size of the image
		iconlbl.setBounds(50, 30, size.width, size.height); //Sets the location of the image
	}
	/**
	 * add icon
	 * @return JPanel
	 */
	private JPanel addIcon() {
		JPanel p = new JPanel(new FlowLayout());
		p.add(iconlbl);
		return p;
	}
	/**
	 * initialize
	 */
	private void initialize() {
		setLayout(new BorderLayout());
		add(addIcon(),BorderLayout.NORTH);
		add(addGrid(),BorderLayout.CENTER);
		add(addButtons(),BorderLayout.SOUTH);
		pack();
	}
	/**
	 * add buttons
	 * @return JPanel
	 */
	private JPanel addButtons() {
		JPanel p=new JPanel(new FlowLayout()); 
		p.add(AddBranchbtn);
		p.add(AddCarbtn);
		p.add(LogOutbtn);
		return p;
	}
	/**
	 * add grid
	 * @return JPanel
	 */
	private JPanel addGrid() {
		JPanel p = new JPanel(new GridLayout(0,3));
		p.add(new JLabel(""));
		p.add(txt);
		return p;
	}
	/**
	 * this method check if there any Branch exists
	 * @return true if exists, false otherwise
	 */
	private boolean CheckIfBranchExist() {
		return Admin.getBranchs().size() > 0 ? true : false;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
