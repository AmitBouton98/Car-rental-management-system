package Screens;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Users.Manager;

/**
 * This class is SignIN or SignUP for Ruppin Rent
 * @author Amit
 *
 */
public class SignInORegister extends JFrame implements ActionListener , Serializable{
private static final long serialVersionUID = -79609587120536097L;
private Manager Admin;
/**
 * SignIn button
 */
private JButton SignIn;
/**
 * SignUp button
 */
private JButton SignUp;
private JLabel iconlbl;
/**
 * this is constructor
 * @param admin 
 */
public SignInORegister(Manager admin) {
	super("Welcome to Ruppin Rent");
	Admin = admin;
	Admin.Save(Admin);
	iconlbl = new JLabel();
	SignIn = new JButton("Sigh in");
	SignIn.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			SignIn S = new SignIn(Admin);
			S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
			Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
		    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
		    S.setLocation(x, y);
			S.setVisible(true);
			dispose();
		}

	});
	SignUp = new JButton("Sigh Up");
	SignUp.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			SignUp S = new SignUp(Admin);
			S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
			Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
		    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
		    S.setLocation(x, y);
			S.setVisible(true);
			dispose();
		}
	});
	initializeIcon();
	initialize();
}
private void initializeIcon() {
	this.iconlbl.setIcon(new ImageIcon("icon//car.png"));
	Dimension size = iconlbl.getPreferredSize(); //Gets the size of the image
	iconlbl.setBounds(50, 30, size.width, size.height); //Sets the location of the image
}

/**
 * Add the buttons for signin or signout
 * @return JPanel
 */
private JPanel addButtons() {
	
	JPanel p=new JPanel(new FlowLayout()); 
	p.add(SignIn);
	p.add(SignUp);
	return p;
}
/**
 * add icon
 * @return JPanel
 */
private JPanel addIcon() {
	JPanel p = new JPanel(new FlowLayout());
	p.add(iconlbl);
	return p;
}
/**
 * initialize
 */
private void initialize() {
	setLayout(new BorderLayout());
	add(addIcon(),BorderLayout.NORTH);
	add(addButtons(),BorderLayout.CENTER);
	pack();
}

@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
}


}
