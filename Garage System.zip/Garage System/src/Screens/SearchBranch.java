package Screens;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Entities.Branch;
import Users.Manager;

/**
 * this class represent search branch frame for customer
 * @author Amit
 *
 */
public class SearchBranch extends JFrame implements ActionListener , Serializable{
	private Manager Admin;
	/**
	 * Serial Number
	 */
	private static final long serialVersionUID = -6709036002416707112L;
	
	String[] columnsName = {"Branch Number","Address" , "Opening Hours"};
	private DefaultTableModel Tabletbl;
	private JButton Exitbtn;
	
	/**
	 * this is constructor for Search branch frame
	 * @param admin
	 * @param email 
	 */
	public SearchBranch(Manager admin, String email) {
		super("Search Branches");
		Admin = admin;
		Tabletbl = new DefaultTableModel(columnsName,0);
		Exitbtn = new JButton("Exit");
		Exitbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				CustomerScreen S = new CustomerScreen(Admin,email);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}
		});
		initializeTable();
		initialize();
	}

	/**
	 * add buttons
	 * @return JPanel
	 */
	public JPanel addButtons() {
		JPanel p=new JPanel(new FlowLayout());
		p.add(Exitbtn);
		return p;
	}
	/**
	 * initialize table
	 */
	public void initializeTable() {
		for(Branch bra : Admin.getBranchs()) {
			Tabletbl.addRow(new Object[] {bra.getNumber(),bra.getLocation(),bra.getOpeninhHours()});
		}
	}
	/**
	 * initialize
	 */
	public void initialize() {
		setLayout(new BorderLayout());
		JTable T = new JTable(Tabletbl);
		T.setEnabled(false);
		add(new JScrollPane(T),BorderLayout.NORTH);
		add(addButtons(),BorderLayout.CENTER);
		pack();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
