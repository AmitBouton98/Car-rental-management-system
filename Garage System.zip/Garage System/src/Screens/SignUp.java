package Screens;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Users.Customer;
import Users.Manager;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * This class represent Screen for SignUP
 * @author Amit
 *
 */
public class SignUp extends JFrame implements ActionListener,Serializable{
	// -------------------------------Class Members------------------------------
	private Manager Admin;
	
	private JLabel Firstlbl;
	private JTextField Firsttxt;
	private JLabel Lastlbl;
	private JTextField Lasttxt;
	private JLabel IDlbl;
	private JTextField IDtxt;
	private JLabel Emaillbl;
	private JTextField Emailtxt;
	private JLabel BirthDay;
	private JLabel DayOfBirthlbl;
	private Choice DayOfBirthCh;
	private JLabel MonthOfBirthlbl;
	private Choice MonthOfBirthCh;
	private JLabel YearOfBirthlbl;
	private Choice YearOfBirthCh;

	private JLabel LicenseYearlbl;
    private JTextField LicenseYeartxt;
	
	private JLabel Passwordlbl;
	private JTextField Passwordtxt;
	private JLabel verifyPasswordlbl;
	private JPasswordField verifyPasswordtxt;
    private JButton finishbtn;
	private JButton cancelbtn;

	
	//Error text
	private JLabel ErrorFirst;
	private JLabel ErrorLast;
	private JLabel ErrorID;
	private JLabel ErrorEmail;
	private JLabel ErrorLicenseYear;
	private JLabel ErrorPassword;
	private JLabel ErrorVarifyPassword;
	// -------------------------------serialVersionUID------------------------------
	/**
	 * This is serial number for Version
	 */
	private static final long serialVersionUID =-5426407224050751131L;
	// -------------------------------Constructors------------------------------
	/**
	 * This is constructor for SignUp
	 * @param admin 
	 */
	public SignUp(Manager admin) {
		super("Sign Up for Ruppin Rent");
		Admin = admin;
		Admin.Save(Admin);
		Firstlbl = new JLabel("First name: ");
		Firsttxt = new JTextField(20);
		Lastlbl = new JLabel("Last name: ");
		Lasttxt = new JTextField(20);
		IDlbl = new JLabel("ID: ");
		IDtxt = new JTextField(9);
		Emaillbl = new JLabel("Email: ");
		Emailtxt = new JTextField(40);
		BirthDay = new JLabel("Birth day");
		DayOfBirthlbl =  new JLabel("Day");
		DayOfBirthCh = new Choice();
		MonthOfBirthlbl =  new JLabel("Month");
		MonthOfBirthCh = new Choice();
		YearOfBirthlbl =  new JLabel("Year");
		YearOfBirthCh = new Choice();
	    LicenseYearlbl=new JLabel("License year");
		LicenseYeartxt=new JTextField(20);
		Passwordlbl = new JLabel("Password: ");
		Passwordtxt = new JTextField(20);
		verifyPasswordlbl = new JLabel("Verify password: ");
		verifyPasswordtxt = new JPasswordField(20);
		
		finishbtn = new JButton("Finish");
		finishbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(Validation() == true) {
					Admin.Save(Admin);
					AddCustumer();
					//  pop up massage that says : "Register successfully"
					JOptionPane.showMessageDialog(null, "Register successfully!", "Register", JOptionPane.PLAIN_MESSAGE);
					SignInORegister S = new SignInORegister(Admin);
					S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
				    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
				    S.setLocation(x, y);
					S.setVisible(true);
					dispose();
				}
				else {
					return;
				}
			}
		});
		cancelbtn = new JButton("Cencel");
		cancelbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SignInORegister S = new SignInORegister(Admin);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}
			
		});
		ErrorFirst = new JLabel("");
		ErrorLast = new JLabel("");
		ErrorID = new JLabel("");
		ErrorEmail  = new JLabel("");
		ErrorLicenseYear  = new JLabel("");
		ErrorPassword  = new JLabel("");
		ErrorVarifyPassword  = new JLabel("");
		  initialize();
		  initializeDate();
	}
	// -----------------------------------------Setters&&Getters--------------------------------------
	// -------------------------------All Methods------------------------------
	/**
	 * add the layout and border layout
	 */
	private void initialize() {
		
		setLayout(new BorderLayout());
		add(addGrid(),BorderLayout.NORTH);
		add(addButtons(),BorderLayout.SOUTH);
		pack();
		}
	
	/**
	 * this method adding buttons for finish and cancel
	 * @return JPanel
	 */
	private JPanel addButtons() {
		
		JPanel p=new JPanel(new FlowLayout()); 
		p.add(finishbtn);
		p.add(cancelbtn);
		return p;
	}
	/**
	 * this method add the date for the Choice options(day/month/year)
	 */
	private void initializeDate() {
		for(int i = 1 ; i < 32; i++) {
			this.DayOfBirthCh.add(Integer.toString(i));
		}
		for(int i = 1 ; i < 13; i++) {
			this.MonthOfBirthCh.add(Integer.toString(i));
		}
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		for(int i = 1 ; i < 101; i++) {
			this.YearOfBirthCh.add(Integer.toString(year - i));
		}
	}
	/**
	 * This function checks the validation of the form
	 * @return
	 */
	private boolean Validation() {
		int count = 0;
		if(NameValidation(this.Firsttxt) == false) {
			count++;
		}
		if (NameValidation(this.Lasttxt) == false) {
			count++;
		}
		if(IDValidation() == false) {
			count++;
		}
		if(EmailValidation() == false) {
			count++;
		}
		if(LicenseYearValidation() == false) {
			count++;
		}
		if(PassValidation() == false) {
			count++;
		}
		if(count> 0)
			return false;
		else {
			String birthDate = this.DayOfBirthCh.getSelectedItem() +"/"+this.MonthOfBirthCh.getSelectedItem()+"/"+this.YearOfBirthCh.getSelectedItem();
			Customer NewCustomer = new Customer(this.Firsttxt.getText(),this.Lasttxt.getText(),Integer.parseInt(this.IDtxt.getText()),this.Emailtxt.getText(),birthDate,Integer.parseInt(this.LicenseYeartxt.getText()),this.Passwordtxt.getText());
			Admin.AddCustomer(NewCustomer);
			DayOfBirthCh.setBackground(Color.GREEN);
			MonthOfBirthCh.setBackground(Color.GREEN);
			YearOfBirthCh.setBackground(Color.GREEN);
			return true;
		}
	}
	/**
	 * Check if the name is valid
	 * @param name - is first / last name
	 * @return true if he valid, false otherwise
	 */
	private boolean NameValidation(JTextField name) {
	    if (name.getText() == null || name.getText().length() == 0 || name.getText().isEmpty()) {
	    	if(name == this.Firsttxt) {
	    		ErrorFirst.setText("Name should contain at least one character");
	    		Firsttxt.setBackground(Color.RED);
	    	}
	    	else {
	    		ErrorLast.setText("Name should contain at least one character");
	    		Lasttxt.setBackground(Color.RED);
	    	}
	    	return false;
	    }
	    for (int i = 0; i < name.getText().length(); i++) {
	        char ch = name.getText().charAt(i);
	        if (!Character.isLetter(ch) && ch != ' ') {
	        	if(name == this.Firsttxt) {
	        		ErrorFirst.setText("Name should contain only alphabetical characters and spaces");
	        		Firsttxt.setBackground(Color.RED);
	        	}
	        	else {
	        		ErrorLast.setText("Name should contain only alphabetical characters and spaces");
	        		Lasttxt.setBackground(Color.RED);
	        	}
	        	return false;
	        }
	    }
	    if (name.getText().contains("  ")) {
        	if(name == this.Firsttxt) {
        		ErrorFirst.setText("Name should not contain consecutive spaces");
        		Firsttxt.setBackground(Color.RED);
        	}
        	else {
        		ErrorLast.setText("Name should not contain consecutive spaces");
        		Lasttxt.setBackground(Color.RED);
        	}
	        return false;
	    }
    	if(name == this.Firsttxt) {
    		ErrorFirst.setText(null);
    		Firsttxt.setBackground(Color.GREEN);
    	}
    	else {
    		ErrorLast.setText(null);
    		Lasttxt.setBackground(Color.GREEN);
    	}
		return true;
	}
	/**
	 * Check if the ID is valid
	 * @return true if he valid, false otherwise
	 */
	private boolean IDValidation() {
	    if (this.IDtxt.getText() == null || this.IDtxt.getText().length() == 0) {
	    	this.ErrorID.setText("Insert ID");
	    	this.IDtxt.setBackground(Color.RED);
	    	return false;
	    }
	    for (int i = 0; i < this.IDtxt.getText().length(); i++) {
	        char ch = this.IDtxt.getText().charAt(i);
	        if (!Character.isDigit(ch)) {
	        	this.ErrorID.setText("ID should contain only digits");
	        	this.IDtxt.setBackground(Color.RED);
	            return false;
	        }
	    }
	    if(this.IDtxt.getText().length() != 9) {
        	this.ErrorID.setText("ID should be lenght 9");
        	this.IDtxt.setBackground(Color.RED);
            return false;
	    }
	    this.ErrorID.setText(null);
    	this.IDtxt.setBackground(Color.GREEN);
	    return true;
	}
	/**
	 * Check if the Email is valid
	 * @return true if he valid, false otherwise
	 */
    /**
     * String and pattern for EmailValidation
     */
    private static final String EMAIL_REGEX = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);

	private boolean EmailValidation() {
	    if (this.Emailtxt.getText() == null || this.Emailtxt.getText().length() == 0) {
	    	this.ErrorEmail.setText("Insert Email");
	    	this.Emailtxt.setBackground(Color.RED);
	    	return false;
	    }
		Matcher matcher = EMAIL_PATTERN.matcher(this.Emailtxt.getText());
        if(!matcher.matches()) {
        	this.ErrorEmail.setText("Email Isn't legal");
        	this.Emailtxt.setBackground(Color.RED);
        	return false;
        }
        for(Customer c : Admin.getCustomers()) {
        	if(c.getEmail().equals(this.Emailtxt.getText())) {
            	this.ErrorEmail.setText("Email already exists");
            	this.Emailtxt.setBackground(Color.RED);
            	return false;
        	}
        }
        this.ErrorEmail.setText(null);
        this.Emailtxt.setBackground(Color.GREEN);
        return true;
	}
	/**
	 * Check if the license year is valid
	 * @return true if he valid, false otherwise
	 */
	private boolean LicenseYearValidation() {
	    if (this.LicenseYeartxt.getText() == null || this.LicenseYeartxt.getText().length() == 0) {
	    	this.ErrorLicenseYear.setText("Insert License Year");
	    	this.LicenseYeartxt.setBackground(Color.RED);
	    	return false;
	    }
	    for (int i = 0; i < this.LicenseYeartxt.getText().length(); i++) {
	        char ch = this.LicenseYeartxt.getText().charAt(i);
	        if (!Character.isDigit(ch)) {
	        	this.ErrorLicenseYear.setText("License Year should contain only digits");
	        	this.LicenseYeartxt.setBackground(Color.RED);
	            return false;
	        }
	    }
		if(Integer.parseInt(this.LicenseYeartxt.getText()) < Integer.parseInt(this.YearOfBirthCh.getSelectedItem())+18) {
        	this.ErrorLicenseYear.setText("Your age should be more than 18 to have a license");
        	this.LicenseYeartxt.setBackground(Color.RED);
            return false;
		}
		this.ErrorLicenseYear.setText(null);
        this.LicenseYeartxt.setBackground(Color.GREEN);
		return true;
	}
	/**
	 * Check if the password is valid
	 * @return true if he valid, false otherwise
	 */
	private boolean PassValidation() {
		if (this.Passwordtxt.getText() == null || this.Passwordtxt.getText().length() == 0) {
	    	this.ErrorPassword.setText("Insert password");
	    	this.Passwordtxt.setBackground(Color.RED);
			if (this.verifyPasswordtxt.getSelectedText() == null || this.verifyPasswordtxt.getSelectedText().length() == 0) {
		    	this.ErrorVarifyPassword.setText("Insert varify password");
		    	this.verifyPasswordtxt.setBackground(Color.RED);
			}
			return false;
		}
		//try {
		//	String verifyPass = new String(this.verifyPasswordtxt.getPassword());
		//}
		//catch (NullPointerException e) {
		//	System.out.println("Caught a NullPointerException: " + e.getMessage());
		//}
		if(!this.Passwordtxt.getText().equals(new String(this.verifyPasswordtxt.getPassword()))) {
	    	this.ErrorPassword.setText("Your password and varify isnt the same");
	    	this.Passwordtxt.setBackground(Color.RED);
	    	this.verifyPasswordtxt.setBackground(Color.RED);
	    	return false;
		}
		this.ErrorPassword.setText(null);
		this.ErrorVarifyPassword.setText(null);
        this.Passwordtxt.setBackground(Color.GREEN);
        this.verifyPasswordtxt.setBackground(Color.GREEN);
        return true;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * this method add panel for date
	 * @return JPanel
	 */
	private JPanel addDate() {
		JPanel  p = new JPanel(new FlowLayout());
		p.add(DayOfBirthlbl);
		p.add(DayOfBirthCh);
		p.add(MonthOfBirthlbl);	
		p.add(MonthOfBirthCh);	
		p.add(YearOfBirthlbl);
		p.add(YearOfBirthCh);
		return p;
	}
	
	/**
	 * this method add grid
	 * @return JPanel
	 */
	private JPanel addGrid() {
		JPanel p = new JPanel(new GridLayout(0,3));
		p.add(Firstlbl);
		p.add(Firsttxt);
		p.add(ErrorFirst);
		p.add(Lastlbl);
		p.add(Lasttxt);
		p.add(ErrorLast);
		p.add(IDlbl);
		p.add(IDtxt);
		p.add(ErrorID);
		p.add(Emaillbl);
		p.add(Emailtxt);
		p.add(ErrorEmail);
		p.add(LicenseYearlbl);
		p.add(LicenseYeartxt);
		p.add(ErrorLicenseYear);
		p.add(Passwordlbl);
		p.add(Passwordtxt);
		p.add(ErrorPassword);
		p.add(verifyPasswordlbl);
		p.add(verifyPasswordtxt);
		p.add(ErrorVarifyPassword);
		p.add(BirthDay);
		p.add(addDate());
		return p;
	}
	/**
	 * this method add cutstomer
	 */
	private void AddCustumer()
	{
		String birthDate = this.DayOfBirthCh.getSelectedItem() +"/"+this.MonthOfBirthCh.getSelectedItem()+"/"+this.YearOfBirthCh.getSelectedItem();
		Customer c = new Customer(this.Firsttxt.getText(),this.Lasttxt.getText(),Integer.parseInt(this.IDtxt.getText()),this.Emailtxt.getText(),birthDate,Integer.parseInt(this.LicenseYeartxt.getText()),this.Passwordtxt.getText());
		Admin.AddCustomer(c);
	} 
	// -------------------------------hashCode equals & toString------------------------------

}
