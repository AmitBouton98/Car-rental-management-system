package Screens;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Entities.Branch;
import Entities.Car;
import Users.Manager;

/**
 * This class represent screen for adding car
 * @author Amit
 *
 */
public class AddCar extends JFrame implements ActionListener , Serializable {
	private Manager Admin;
	/**
	 * This is serial number for Version
	 */
	private static final long serialVersionUID = 8252153055359884038L;
	
	private JLabel LicenseNumlbl;
	private JTextField LicenseNumtxt;
	private JLabel Yearlbl;
	private JTextField Yeartxt;
	private JLabel Modellbl;
	private JTextField Modeltxt;
	private JLabel SecondaryModellbl;
	private JTextField SecondaryModeltxt;
	private JLabel Categorylbl;
	private Choice CategoryCh;
	private JLabel Gearboxlbl;
	private Choice GearboxCh;
	private JLabel RentPerDaylbl;
	private JTextField RentPerDaytxt;
	
	private JLabel Brancheslbl;
	private Choice BranchesCh;
	
	private JLabel ErrorLicenseNumlbl;
	private JLabel ErrorYearlbl;
	private JLabel ErrorModellbl;
	private JLabel ErrorSecondaryModellbl;
	private JLabel ErrorCategorylbl;
	private JLabel ErrorGearboxlbl;
	private JLabel ErrorRentPerDaylbl;

	
	private JButton Finishbtn;
	private JButton Cancelbtn;
	
	/**
	 * this is constructor for frame AddCar
	 * @param admin
	 */
	public AddCar(Manager admin) {
		super("Add New Car For Ruppin Rent");
		Admin = admin;
		Admin.Save(Admin);
		LicenseNumlbl = new JLabel("License Number: ");
		LicenseNumtxt = new JTextField(20);
		Yearlbl = new JLabel("Year: ");
		Yeartxt = new JTextField(20);
		Modellbl = new JLabel("Model: ");
		Modeltxt = new JTextField(20);
		SecondaryModellbl = new JLabel("Secondary Model: ");
		SecondaryModeltxt = new JTextField(20);
		Categorylbl = new JLabel("Category: ");
		CategoryCh = new Choice();
		Gearboxlbl = new JLabel("Gearbox: ");
		GearboxCh = new Choice();
		RentPerDaylbl = new JLabel("Rent Per Day: ");
		RentPerDaytxt = new JTextField(20);
		
		Brancheslbl = new JLabel("Branch number: ");
		BranchesCh = new Choice();
		
		ErrorLicenseNumlbl = new JLabel("");
		ErrorYearlbl = new JLabel("");
		ErrorModellbl = new JLabel("");
		ErrorSecondaryModellbl = new JLabel("");
		ErrorCategorylbl = new JLabel("");
		ErrorGearboxlbl = new JLabel("");
		ErrorRentPerDaylbl = new JLabel("");
		
		Finishbtn = new JButton("Finish");
		Cancelbtn = new JButton("Cancel");
		
		Finishbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(Validation() == false) {
					return;
				}
				else {
					AddNewCar();
					//  pop up massage that says : "Added successfully"
					JOptionPane.showMessageDialog(null, "Added successfully!", "Added successfully", JOptionPane.PLAIN_MESSAGE);
					ManagerScreen S = new ManagerScreen(Admin);
					S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
					Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
				    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
				    S.setLocation(x, y);
					S.setVisible(true);
					dispose();
				}
			}
		});
		
		Cancelbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ManagerScreen S = new ManagerScreen(Admin);
				S.setIconImage(Toolkit.getDefaultToolkit().getImage("icon//Icon.jpg"));
				Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (int) ((dimension.getWidth() - S.getWidth()) / 2);
			    int y = (int) ((dimension.getHeight() - S.getHeight()) / 2);
			    S.setLocation(x, y);
				S.setVisible(true);
				dispose();
			}

		});
		initializeCategory();
		initializeGrearBox();
		initializeBranchNumber();
		initialize();

	}

	/**
	 * initialize Branch Number
	 */
	private void initializeBranchNumber() {
		for(Branch bra : Admin.getBranchs()) {
			this.BranchesCh.add(Integer.toString(bra.getNumber()));;
		}
		
	}

	/**
	 * initialize Grear Box
	 */
	private void initializeGrearBox() {
		this.GearboxCh.add("Manual");
		this.GearboxCh.add("Automatic");
	}

	/**
	 * initialize Category
	 */
	private void initializeCategory() {
		this.CategoryCh.add("Mini");
		this.CategoryCh.add("Sadan");
		this.CategoryCh.add("Manager");
		this.CategoryCh.add("SUV");
		
	}

	/**
	 * add grid
	 * @return JPanel
	 */
	private JPanel addGrid() {
		JPanel p = new JPanel(new GridLayout(0,3));
		p.add(LicenseNumlbl);
		p.add(LicenseNumtxt);
		p.add(ErrorLicenseNumlbl);
		
		p.add(Yearlbl);
		p.add(Yeartxt);
		p.add(ErrorYearlbl);
		
		p.add(Modellbl);
		p.add(Modeltxt);
		p.add(ErrorModellbl);
		
		p.add(SecondaryModellbl);
		p.add(SecondaryModeltxt);
		p.add(ErrorSecondaryModellbl);
		
		p.add(Categorylbl);
		p.add(CategoryCh);
		p.add(ErrorCategorylbl);
		
		p.add(Gearboxlbl);
		p.add(GearboxCh);
		p.add(ErrorGearboxlbl);
		
		p.add(RentPerDaylbl);
		p.add(RentPerDaytxt);
		p.add(ErrorRentPerDaylbl);
		
		p.add(Brancheslbl);
		p.add(BranchesCh);
		p.add(new JLabel(""));
		return p;
	}
	
	/**
	 * add buttons
	 * @return JPanel
	 */
	private JPanel addButtons() {
		
		JPanel p=new JPanel(new FlowLayout()); 
		p.add(Finishbtn);
		p.add(Cancelbtn);
		return p;
	}
	
	/**
	 * initialize
	 */
	private void initialize() {
		
		setLayout(new BorderLayout());
		add(addGrid(),BorderLayout.NORTH);
		add(addButtons(),BorderLayout.CENTER);
		setSize(800,300);
	}
	/**
	 * this method check validation of the input
	 * @return true if valid, false other wise
	 */
	private boolean Validation() {
		int count = 0 ;
		if (CheckLicanse() == false)
		{
			count++;
		}
		if (CheckYear() == false)
		{
			count++;
		}
		if (CheckRentPerDay() == false)
		{
			count++;
		}
		if(CheckModel() == false)
		{
			count++;
		}
		if(CheckSecondaryModel() == false)
		{
			count++;
		}
		if(count > 0)
		{
			return false;
		}
		else {
			this.CategoryCh.setBackground(Color.GREEN);
			this.GearboxCh.setBackground(Color.GREEN);
			this.BranchesCh.setBackground(Color.GREEN);
			return true;
		}
	}
	/**
	 * this method check if model is valid
	 * @return true if valid, false other wise
	 */
	private boolean CheckModel() {

		if(this.Modeltxt.getText().isEmpty() || this.Modeltxt.getText() == "" || this.Modeltxt.getText().length() == 0)
		{
			this.ErrorModellbl.setText("Insert Model");
			this.Modeltxt.setBackground(Color.RED);
			return false;
		}
		this.ErrorModellbl.setText(null);
		this.Modeltxt.setBackground(Color.GREEN);
		return true;
	}
	/**
	 * this method check if secondary model is valid
	 * @return true if valid, false other wise
	 */
	private boolean CheckSecondaryModel() {
		if(this.SecondaryModeltxt.getText().isEmpty() || this.SecondaryModeltxt.getText() == "" || this.SecondaryModeltxt.getText().length() == 0)
		{
			this.ErrorSecondaryModellbl.setText("Insert Model");
			this.SecondaryModeltxt.setBackground(Color.RED);
			return false;
		}
		this.ErrorSecondaryModellbl.setText(null);
		this.SecondaryModeltxt.setBackground(Color.GREEN);
		return true;
	}
	/**
	 * this method check if licanse number is valid
	 * @return true if valid, false other wise
	 */
	private boolean CheckLicanse() {
		 if (this.LicenseNumtxt.getText() == null || this.LicenseNumtxt.getText().length() == 0) {
		    	this.ErrorLicenseNumlbl.setText("Insert Lisence Number");
		    	this.LicenseNumtxt.setBackground(Color.RED);
		    	return false;
		    }
		    for (int i = 0; i < this.LicenseNumtxt.getText().length(); i++) {
		        char ch = this.LicenseNumtxt.getText().charAt(i);
		        if (!Character.isDigit(ch)) {
		        	this.ErrorLicenseNumlbl.setText("License Number should contain only digits");
		        	this.LicenseNumtxt.setBackground(Color.RED);
		            return false;
		        }
		    }
		    if(this.LicenseNumtxt.getText().length() != 7 && this.LicenseNumtxt.getText().length() != 8) {
	        	this.ErrorLicenseNumlbl.setText("ID should be lenght 7 or 8");
	        	this.LicenseNumtxt.setBackground(Color.RED);
	            return false;
		    }
		    this.ErrorLicenseNumlbl.setText(null);
	    	this.LicenseNumtxt.setBackground(Color.GREEN);
		    return true;
	}

	/**
	 * this method check if year is valid 
	 * @return true if valid, false other wise
	 */
	private boolean CheckYear() {
		 if (this.Yeartxt.getText() == null || this.Yeartxt.getText().length() == 0) {
		    	this.ErrorYearlbl.setText("Insert Year");
		    	this.Yeartxt.setBackground(Color.RED);
		    	return false;
		    }
		    for (int i = 0; i < this.Yeartxt.getText().length(); i++) {
		        char ch = this.Yeartxt.getText().charAt(i);
		        if (!Character.isDigit(ch)) {
		        	this.ErrorYearlbl.setText("Year should contain only digits");
		        	this.Yeartxt.setBackground(Color.RED);
		            return false;
		        }
		    }
		    if(Integer.parseInt(this.Yeartxt.getText()) > 2023) {
	        	this.ErrorYearlbl.setText("Year cant be in the future");
	        	this.Yeartxt.setBackground(Color.RED);
	            return false;
		    }
		    this.ErrorYearlbl.setText(null);
	    	this.Yeartxt.setBackground(Color.GREEN);
		    return true;
	}

	/**
	 * this method check if rent per day is valid 
	 * @return true if valid, false other wise
	 */
	private boolean CheckRentPerDay() {
		if(this.RentPerDaytxt.getText().isEmpty() || this.RentPerDaytxt.getText().length() == 0 || this.RentPerDaytxt.getText() == "") {
			this.ErrorRentPerDaylbl.setText("Insert Price");
			this.RentPerDaytxt.setBackground(Color.RED);
			return false;
		}
	    for (int i = 0; i < this.RentPerDaytxt.getText().length(); i++) {
	        char ch = this.RentPerDaytxt.getText().charAt(i);
	        if(ch == '.')
	        {
	        	for (i = i+1 ; i < this.RentPerDaytxt.getText().length() ; i++) {
	    	        ch = this.RentPerDaytxt.getText().charAt(i);
	    	        if (!Character.isDigit(ch)) {
	    		        this.ErrorRentPerDaylbl.setText("Price should contain only digits and one point");
	    		        this.RentPerDaytxt.setBackground(Color.RED);
	    		         return false;
	    		        }
	        	}
	        	this.ErrorRentPerDaylbl.setText(null);
	        	this.RentPerDaytxt.setBackground(Color.GREEN);
	            return true;
	        }
	        if (!Character.isDigit(ch)) {
	        this.ErrorRentPerDaylbl.setText("Price should contain only digits");
	        this.RentPerDaytxt.setBackground(Color.RED);
	         return false;
	        }
	    }
    	this.ErrorRentPerDaylbl.setText(null);
    	this.RentPerDaytxt.setBackground(Color.GREEN);
        return true;
	}

	/**
	 * this method add new car
	 */
	private void AddNewCar() {
		Car NewCar = new Car(Integer.parseInt(LicenseNumtxt.getText()),Integer.parseInt(this.Yeartxt.getText()),this.Modeltxt.getText(),this.SecondaryModeltxt.getText(),this.CategoryCh.getSelectedItem(),this.GearboxCh.getSelectedItem(),Double.parseDouble(this.RentPerDaytxt.getText()));
		Admin.AddCar(NewCar);
		// need to check down here
		Admin.AddCarPerStore(Integer.parseInt(this.BranchesCh.getSelectedItem()), NewCar);
		//Admin.getCarsPerStore().get(Integer.parseInt(this.BranchesCh.getSelectedItem())).add(NewCar);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
